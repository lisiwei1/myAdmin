import Vue from 'vue'
import store from '@/store'

Vue.directive('hasPermShow', {
  inserted : function(el, binding){
    const { value } = binding
    
    if (value && value instanceof Array && value.length > 0) {
      const data = localStorage.getItem('btnPerms')
      const list = JSON.parse(data)
      if(list.length == 0){
        el.parentNode && el.parentNode.removeChild(el)
        return
      }
      const perms = value
      const flag = list.some(p => {
        return perms.includes(p)
      })
      if (!flag) {
        el.parentNode && el.parentNode.removeChild(el)
      }
    }
  }
})