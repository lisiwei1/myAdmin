const namespaced = true
const state = {
  showLoading: false,
};

const getters = {
  GET_SHOWLOADING({ showLoading }) {
    return showLoading;
  },
}
// 同步操作
const mutations = {
  SET_SHOWLOADING(state, data) {
    state.showLoading = data
  },
}
// 异步操作
const actions = {
}
export default {
  state,
  namespaced,
  getters,
  mutations,
  actions
}
