import RouteInfo from './RouteInfo'

export default RouteInfo
