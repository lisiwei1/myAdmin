import Role from './Role'

export default Role