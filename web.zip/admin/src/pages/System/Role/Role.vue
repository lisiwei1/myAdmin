<template>
  <div>
    <el-button @click="handleAdd()" type="primary" plain size="mini" icon="el-icon-plus">新增</el-button>
    <el-button @click="getList()" type="primary" size="mini" icon="el-icon-search">查询</el-button>
    <el-table :data="tableData" :default-sort = "{prop: 'orderNum', order: 'ascending'}"
     v-loading="loading" :height="tableHeight" style="width: 100%">
      <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="roleName" label="角色名" width="150"></el-table-column>
      <el-table-column prop="roleKey" label="权限字符" width="120"></el-table-column>
      <el-table-column prop="status" label="状态" :formatter="statusFormatter" width="150"></el-table-column>
      <el-table-column prop="orderNum" label="显示顺序" width="200"></el-table-column>
      <el-table-column prop="remark" label="备注" width="200"></el-table-column>
      <el-table-column prop="createBy" label="创建者" width="150"></el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="200"></el-table-column>
      <el-table-column fixed="right" label="操作" width="200">
        <template slot-scope="scope">
          <el-button @click="handleEdit(scope.row)" type="text" size="small" icon="el-icon-edit">修改</el-button>
          <el-button @click="handleConfigEdit(scope.row)" type="text" size="small" icon="el-icon-s-tools">参数设置</el-button>
          <el-button @click="handleDelete(scope.row)" size="mini" type="text" icon="el-icon-delete">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :title="title" :visible.sync="open"
      width="600px" :close-on-click-modal="false">
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-form-item label="角色名称" prop="roleName">
          <el-input v-model="form.roleName" placeholder="请输入角色名称"></el-input>
        </el-form-item>
        <el-form-item label="权限字符" prop="roleKey">
          <el-input v-model="form.roleKey"  placeholder="请输入权限字符"></el-input>
        </el-form-item>
        <el-form-item label="显示顺序" prop="orderNum">
          <el-input-number v-model="form.orderNum" controls-position="right" :min="0" />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="form.status">
            <el-radio label="1">正常</el-radio>
            <el-radio label="0">停用</el-radio>
          </el-radio-group>
        </el-form-item>
          <el-form-item label="菜单权限">
             <el-checkbox v-model="menuExpand" @change="handleCheckedTreeExpand($event)">展开/折叠</el-checkbox>
             <el-checkbox v-model="menuNodeAll" @change="handleCheckedTreeNodeAll($event)">全选/全不选</el-checkbox>
              <el-tree
                class="tree-border"
                ref="menuTree"
                :props="props"
                :data="menuOptions"
                node-key="pkid"
                :check-strictly="true"
                show-checkbox>
              </el-tree>
          </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" placeholder="请输入内容"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
    <el-dialog :title="configTitle" :visible.sync="isConfigOpen"
      width="800px" :close-on-click-modal="false">
      <el-form ref="configForm" :model="configForm" label-width="80px">
        <el-form-item label="参数类型">
          <el-checkbox :indeterminate="configForm.isIndeterminate" v-model="configForm.checkAll" @change="handleCheckAllChange">全选</el-checkbox>
            <div style="margin: 15px 0;"></div>
            <el-checkbox-group v-model="configForm.checkedConfigs" @change="handleCheckedConfigsChange">
              <el-checkbox v-for="config in configForm.configs" :label="config.pkid" :key="config.pkid">{{config.typeCode}} {{config.typeName}}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitConfigForm" v-loading.fullscreen.lock="fullscreenLoading">保存</el-button>
        <el-button @click="cancelConfigForm">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'Role',
  data () {
    return {
      tableHeight: 0,
      loading: false,
      tableData: [],
      // 是否显示弹出层
      open: false,
      // 弹出层标题
      title: '',
      form: {
        roleId: '',
        roleName: '',
        roleKey: '',
        orderNum: 0,
        status: '1',
        remark: ''
      },
      rules: {
        roleName: [
          { required: true, message: '角色名称不能为空', trigger: 'blur' }
        ],
        roleKey: [
          { required: true, message: '权限字符不能为空', trigger: 'blur' }
        ],
        orderNum: [
          { required: true, message: '显示顺序不能为空', trigger: 'blur' }
        ]
      },
      menuOptions: [],
      props: {
        label: 'menuName'
      },
      menuExpand: false,
      menuNodeAll: false,

      fullscreenLoading: false,
      configTitle: '',
      isConfigOpen: false,
      // 参数表单配置
      configForm: {
        isIndeterminate: true,
        checkAll: false,
        checkedConfigs: [],
        configs: [],
        roleId: ''
      },
      configTypeOption: []
    }
  },
  created () {
    this.getList()
  },
  mounted () {
    this.$nextTick(() => {
      this.tableHeight = window.innerHeight - 230
    })
  },
  methods: {
    getList () {
      this.loading = true
      this.$Api.getRoleList().then((result) => {
        this.loading = false
        this.tableData = result
      }).catch(() => {
        this.loading = false
      })
    },
    reSet () {
      Object.keys(this.form).forEach(key => { this.form[key] = undefined })
      this.form.orderNum = 0
      this.form.status = '1'
      this.menuExpand = false
      this.menuNodeAll = false
    },
    handleAdd () {
      this.reSet()
      this.$Api.getMenuList().then((result) => {
        this.menuOptions = result
        this.title = '添加角色'
        this.open = true
        this.$refs.menuTree.setCheckedKeys([])
      })
    },
    // 删除用户
    handleDelete (row) {
      let pkid = row.pkid
      this.$confirm('是否确认删除角色: ' + row.roleName + ' ?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$Api.deleteRole({ pkid }).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    statusFormatter (row, column) {
      if (row.status === 1) {
        return '正常'
      } else if (row.status === 0) {
        return '停用'
      }
      return row.status
    },
    handleEdit (row) {
      this.reSet()
      let pkid = row.pkid
      this.title = '修改角色'
      this.$Api.getRoleDetail({ pkid }).then((result) => {
        let role = result.role
        this.form.roleId = role.pkid
        this.form.roleName = role.roleName
        this.form.status = role.status.toString()
        this.form.roleKey = role.roleKey
        this.form.orderNum = role.orderNum
        this.$Api.getMenuList().then((data) => {
          this.menuOptions = data
          this.$nextTick(_ => {
            this.$refs.menuTree.setCheckedKeys(result.menuIds)
          })
          this.open = true
        })
      })
    },
    handleConfigEdit (row) {
      this.configForm.isIndeterminate = true
      this.configForm.checkAll = false
      this.configForm.checkedConfigs = []
      this.configForm.configs = []
      this.configForm.roleId = ''

      this.configForm.roleId = row.pkid
      this.configTitle = '设置用户参数类型权限'
      this.$Api.getConfigTypeList().then((result) => {
        this.configForm.configs = result
        this.configTypeOption = result
        let roleId = row.pkid
        this.$Api.getRoleConfigTypeDetail({ roleId }).then((response) => {
          this.configForm.checkedConfigs = response.map(item => { return item.configTypeId })
          this.isConfigOpen = true
        })
      }).catch()
    },
    submitConfigForm () {
      let roleId = this.configForm.roleId
      let configIds = this.configForm.checkedConfigs
      this.fullscreenLoading = true
      this.$Api.editRoleConfigType({ roleId, configIds }).then((response) => {
        this.fullscreenLoading = false
        this.getList()
        this.isConfigOpen = false
        this.$message({
          message: '保存成功',
          type: 'success'
        })
      }).catch(() => {
        this.fullscreenLoading = false
      })
    },
    cancelConfigForm () {
      this.isConfigOpen = false
    },
    cancel () {
      this.open = false
    },
    submitForm () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          if (this.form.roleId == undefined) {
            let roleKey = this.form.roleKey
            let orderNum = this.form.orderNum
            let roleName = this.form.roleName
            let status = this.form.status
            let remark = this.form.remark
            let menuIds = this.$refs.menuTree.getCheckedKeys().concat(this.$refs.menuTree.getHalfCheckedKeys())
            this.$Api.addRole({ roleKey, orderNum, roleName, status, menuIds, remark }).then(response => {
              this.$message({
                message: '添加成功',
                type: 'success'
              })
              this.open = false
              this.getList()
            })
          } else {
            let roleId = this.form.roleId
            let roleKey = this.form.roleKey
            let orderNum = this.form.orderNum
            let roleName = this.form.roleName
            let status = this.form.status
            let remark = this.form.remark
            let menuIds = this.$refs.menuTree.getCheckedKeys().concat(this.$refs.menuTree.getHalfCheckedKeys())
            this.$Api.editRole({ roleId, roleKey, orderNum, roleName, status, menuIds, remark }).then(response => {
              this.$message({
                message: '添加成功',
                type: 'success'
              })
              this.open = false
              this.getList()
            })
          }
        }
      })
    },
    // 树权限（展开/折叠）
    handleCheckedTreeExpand (value) {
      let treeList = this.menuOptions
      for (let i = 0; i < treeList.length; i++) {
        this.$refs.menuTree.store.nodesMap[treeList[i].pkid].expanded = value
      }
    },
    // 树权限（全选/全不选）
    handleCheckedTreeNodeAll (value) {
      this.$refs.menuTree.setCheckedNodes(value ? this.menuOptions : [])
    },
    // 全选
    handleCheckAllChange (val) {
      this.configForm.checkedConfigs = val ? this.configTypeOption.map(item => { return item.pkid }) : []
      this.configForm.isIndeterminate = false
    },
    handleCheckedConfigsChange (value) {
      let checkedCount = value.length
      this.configForm.checkAll = checkedCount === this.configForm.configs.length
      this.configForm.isIndeterminate = checkedCount > 0 && checkedCount < this.configForm.configs.length
    }
  }
}
</script>

<style>
  .tree-border {
      margin-top: 5px;
      border: 1px solid #e5e6e7;
      background: #fff none;
      border-radius: 4px;
  }
</style>
