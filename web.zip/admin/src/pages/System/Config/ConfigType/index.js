import ConfigType from './ConfigType'

export default ConfigType