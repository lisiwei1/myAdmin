<template>
  <div>
    <el-button @click="handleAdd()" type="primary" plain size="mini" icon="el-icon-plus" v-hasPermShow="['config:type:add']">新增</el-button>
    <el-button @click="search()" type="primary" size="mini" icon="el-icon-search">查询</el-button>
   <el-table :data="tableData" style="width: 100%" :height="tableHeight" v-loading="loading"
      :default-sort = "{prop: 'orderNum', order: 'ascending'}">
      <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="typeCode" label="类型编码" width="90"></el-table-column>
      <el-table-column prop="typeName" label="类型名称" width="180"></el-table-column>
      <el-table-column prop="orderNum" label="显示顺序" width="80"></el-table-column>
      <el-table-column prop="createBy" label="创建者" width="100"></el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="160"></el-table-column>
      <el-table-column prop="updateBy" label="更新者" width="100"></el-table-column>
      <el-table-column prop="updateTime" label="更新时间" width="160"></el-table-column>
      <el-table-column prop="remark" label="备注" width="150"></el-table-column>
      <el-table-column fixed="right" label="操作" width="180">
        <template slot-scope="scope">
          <el-button @click="handleEdit(scope.row)" type="text" size="small" icon="el-icon-edit" v-hasPermShow="['config:type:edit']">修改</el-button>
          <el-button @click="handleDelete(scope.row)" size="mini" type="text" icon="el-icon-delete" v-hasPermShow="['config:type:delete']">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :title="title" :visible.sync="open"
      width="600px" :close-on-click-modal="false">
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-form-item label="类型编码" prop="typeCode">
          <el-input v-model="form.typeCode" :disabled="isEdit" placeholder="请输入类型编码"></el-input>
        </el-form-item>
        <el-form-item label="类型名称" prop="typeName">
          <el-input v-model="form.typeName"  placeholder="请输入类型名称"></el-input>
        </el-form-item>
        <el-form-item label="显示顺序" prop="orderNum">
          <el-input-number v-model="form.orderNum" controls-position="right" :min="0" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" placeholder="请输入内容"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'ConfigType',
  components: {
  },
  data () {
    return {
      loading: false,
      tableData: [],
      title: '',
      open: false,
      form: {
        pkid: '',
        typeCode: '',
        typeName: '',
        orderNum: '',
        remark: ''
      },
      isEdit: false,
      rules: {
        typeCode: [
          { required: true, message: '类型编码不能为空', trigger: 'blur' }
        ],
        typeName: [
          { required: true, message: '类型名称不能为空', trigger: 'blur' }
        ],
        orderNum: [
          { required: true, message: '显示顺序不能为空', trigger: 'blur' }
        ]
      },
      tableHeight: 0
    }
  },
  created () {
    this.search()
  },
  mounted () {
    this.$nextTick(() => {
      this.tableHeight = window.innerHeight - 230
    })
  },
  methods: {
    search () {
      this.loading = true
      this.$Api.getConfigTypeListByUser().then((result) => {
        this.loading = false
        this.tableData = result
      }).catch(() => { this.loading = false })
    },
    reSet () {
      Object.keys(this.form).forEach(key => { this.form[key] = undefined })
      this.form.orderNum = 0
    },
    handleAdd () {
      this.reSet()
      this.title = '添加参数类型'
      this.isEdit = false
      this.open = true
    },
    handleEdit (row) {
      let pkid = row.pkid
      this.reSet()
      this.$Api.getTypeDetail({ pkid }).then((result) => {
        this.form = { ...result }
        this.title = '编辑参数类型'
        this.isEdit = true
        this.open = true
      })
    },
    handleDelete (row) {
      let pkid = row.pkid
      console.log('row', row)
      this.$confirm('是否确认删除参数类型: ' + row.typeName + ' ?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$Api.deleteConfigType({ pkid }).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.search()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    submitForm () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          if (this.form.pkid == undefined) {
            let typeCode = this.form.typeCode
            let typeName = this.form.typeName
            let orderNum = this.form.orderNum
            let remark = this.form.remark
            console.log(this.form)
            this.$Api.addConfigType({ typeCode, typeName, orderNum, remark }).then((result) => {
              this.search()
              this.open = false
              this.$message({
                message: '添加成功',
                type: 'success'
              })
            }
            )
          } else {
            let pkid = this.form.pkid
            let typeCode = this.form.typeCode
            let typeName = this.form.typeName
            let orderNum = this.form.orderNum
            let remark = this.form.remark
            this.$Api.editConfigType({ pkid, typeCode, typeName, orderNum, remark }).then((result) => {
              this.search()
              this.open = false
              this.$message({
                message: ' 修改成功',
                type: 'success'
              })
            }
            )
          }
        }
      })
    },
    cancel () {
      this.open = false
    }
  }
}
</script>

<style>
</style>
