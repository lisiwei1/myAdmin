<template>
  <div>
    <el-form :inline="true" :model="formInline" class="demo-form-inline">
      <el-form-item label="参数类型">
        <el-select v-model="formInline.typeValue" placeholder="请选择" @change="selectChangeFn"  size="small">
            <el-option
              v-for="item in formInline.typeOptions"
              :key="item.typeCode"
              :label="item.typeName + '(' + item.typeCode + ')'"
              :value="item.typeCode">
              <span style="float: left">{{ item.typeName }}</span>
              <span style="float: right; color: #8492a6; font-size: 13px">{{ item.typeCode }}</span>
            </el-option>
        </el-select>
      </el-form-item>
     <el-form-item label="状态">
        <el-select v-model="formInline.status" clearable placeholder="请选择" size="mini" class="width120">
            <el-option
              v-for="item in formInline.statusOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
      </el-form-item>
      <el-form-item>
        <el-button @click="handleAdd()" type="primary" v-hasPermShow="['config:detail:add']"
        plain size="mini" icon="el-icon-plus">新增</el-button>
        <el-button @click="search()" type="primary" size="mini" icon="el-icon-search">查询</el-button>
      </el-form-item>
    </el-form>
   <el-table :data="tableData.filter(data => !searchValue || data.configKey.toLowerCase().includes(searchValue.toLowerCase()))"
      :height="tableHeight" v-loading="loading"
      :default-sort = "{prop: 'orderNum', order: 'ascending'}" style="width: 100%">
      <el-table-column type="index" width="50"></el-table-column>
      <!-- <el-table-column prop="typeCode" label="参数编码"  width="80"></el-table-column> -->
      <!-- <el-table-column prop="typeCode" label="参数类型" :formatter="typeNameFormatter" width="150"></el-table-column> -->
      <el-table-column prop="orderNum" label="显示顺序" width="80"></el-table-column>
      <el-table-column prop="configName" label="参数名称" width="150"></el-table-column>
      <el-table-column prop="configKey" label="参数键名" width="150"></el-table-column>
      <el-table-column prop="configValue" label="参数键值" width="150"></el-table-column>
      <!-- <el-table-column prop="status" label="状态" :formatter="statusFormatter" width="60"></el-table-column> -->
      <el-table-column prop="status" label="状态" width="80">
        <template slot-scope="scope">
          <el-switch v-model="scope.row.status" :active-value='1' :inactive-value='0'
           @change="handleStatusChange(scope.row)" active-color="#13ce66" inactive-color="#ff4949">
          </el-switch>
        </template>
      </el-table-column>
      <el-table-column prop="createBy" label="创建者" width="80"></el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="160"></el-table-column>
      <el-table-column prop="updateBy" label="更新者" width="80"></el-table-column>
      <el-table-column prop="updateTime" label="更新时间" width="160"></el-table-column>
      <el-table-column prop="remark" label="备注" width="150"></el-table-column>
      <el-table-column fixed="right" width="180">
         <template slot="header" slot-scope="scope">
                <el-input
                  clearable
                  v-model="searchValue"
                  size="mini"
                  placeholder="输入参数键名搜索"/>
              </template>
        <template slot-scope="scope">
          <el-button @click="handleEdit(scope.row)" v-hasPermShow="['config:detail:edit']"
          type="text" size="small" icon="el-icon-edit">修改</el-button>
          <el-button @click="handleDelete(scope.row)" v-hasPermShow="['config:detail:delete']"
           size="mini" type="text" icon="el-icon-delete">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :title="title" :visible.sync="open" width="600px" :close-on-click-modal="false">
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-form-item label="参数类型" prop="typeCode">
          <el-select v-model="form.typeCode" :disabled="form.isEdit" placeholder="请选择参数类型">
            <el-option
              v-for="item in typeCodeOptions"
              :key="item.typeCode"
              :label="item.typeName + '(' + item.typeCode + ')'"
              :value="item.typeCode">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="参数名称" prop="configName">
          <el-input v-model="form.configName"  placeholder="请输入参数名称"></el-input>
        </el-form-item>
        <el-form-item label="参数键名" prop="configKey">
          <el-input v-model="form.configKey" :disabled="form.isEdit" placeholder="请输入参数键名"></el-input>
        </el-form-item>
        <el-form-item label="参数键值" prop="configValue">
          <el-input v-model="form.configValue"  placeholder="请输入参数键值"></el-input>
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="form.status">
            <el-radio label="1">正常</el-radio>
            <el-radio label="0">停用</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="显示顺序" prop="orderNum">
          <el-input-number v-model="form.orderNum" controls-position="right" :min="0" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" placeholder="请输入内容"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm" v-loading.fullscreen.lock="fullscreenLoading">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'ConfigDetail',
  data () {
    return {
      fullscreenLoading: false,
      searchValue: '',
      loading: false,
      tableHeight: 0,
      tableData: [],
      title: '',
      open: false,
      form: {
        pkid: '',
        typeCode: '',
        configName: '',
        configKey: '',
        configValue: '',
        orderNum: '',
        status: '',
        remark: '',
        isEdit: false
      },
      rules: {
        typeCode: [
          { required: true, message: '类型不能为空', trigger: 'blur' }
        ],
        configName: [
          { required: true, message: '参数名称不能为空', trigger: 'blur' }
        ],
        configKey: [
          { required: true, message: '参数键名不能为空', trigger: 'blur' }
        ],
        configValue: [
          { required: true, message: '参数键值不能为空', trigger: 'blur' }
        ],
        orderNum: [
          { required: true, message: '显示顺序不能为空', trigger: 'blur' }
        ]
      },
      typeCodeOptions: [],

      formInline: {
        typeValue: '',
        typeOptions: [],
        status: '',
        statusOptions: [
          { label: '全部', value: '' }, { label: '正常', value: 1 }, { label: '停用', value: 0 }
        ]
      }
    }
  },
  created () {
    this.getTypeData()
  },
  mounted () {
    this.$nextTick(() => {
      this.tableHeight = window.innerHeight - 230
    })
  },
  methods: {
    getTypeData () {
      this.loading = true
      this.$Api.getConfigTypeListByUser().then((result) => {
        this.formInline.typeOptions = result
        this.formInline.typeValue = result[0].typeCode
        this.search()
      }).catch(() => { this.loading = false })
    },
    search (pkid) {
      this.loading = true
      let typeCode = this.formInline.typeValue
      let status = this.formInline.status
      this.$Api.getConfigTypeListByUser().then((result) => {
        this.typeCodeOptions = result
        this.$Api.getConfigDetailList({ typeCode, status }).then((result) => {
          this.loading = false
          this.tableData = result
        }).catch(() => { this.loading = false })
      }).catch(() => { this.loading = false })
    },
    selectChangeFn (val) {
      this.search()
    },
    reSet () {
      Object.keys(this.form).forEach(key => { this.form[key] = undefined })
      this.form.orderNum = 0
      this.form.status = '1'
    },
    handleAdd () {
      this.reSet()
      this.$Api.getConfigTypeListByUser().then((result) => {
        this.form.typeCode = this.formInline.typeValue
        this.typeCodeOptions = result
        this.title = '添加参数'
        this.form.isEdit = false
        this.open = true
      })
    },
    handleEdit (row) {
      let pkid = row.pkid
      this.reSet()
      this.$Api.getConfigDetail({ pkid }).then((result) => {
        this.form = { ...result }
        this.form.status = this.form.status.toString()
        this.title = '修改参数'
        this.form.isEdit = true
        this.open = true
      })
    },
    handleDelete (row) {
      let pkid = row.pkid
      console.log('row', row)
      this.$confirm('是否确认删除参数: ' + row.configName + ' ?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$Api.deleteConfig({ pkid }).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.search()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    statusFormatter (row, column) {
      if (row.status == 1) {
        return '正常'
      } else if (row.status == 0) {
        return '停用'
      }
      return row.status
    },
    handleStatusChange (row) {
      let text = row.status === 1 ? '启用' : '停用'
      this.$confirm('确认要' + text + '参数: ' + row.configName + ' 吗?"', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        let pkid = row.pkid
        let status = row.status
        this.loading = true
        this.$Api.editConfigDeatilStatus({ pkid, status }).then((res) => {
          this.loading = false
          this.search()
        }).catch(() => {
          this.loading = false
          row.status = row.status === 0 ? 1 : 0
        })
      }).catch(() => {
        row.status = row.status === 0 ? 1 : 0
      })
    },
    submitForm () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          if (this.form.pkid === undefined) {
            let typeCode = this.form.typeCode
            let configName = this.form.configName
            let configKey = this.form.configKey
            let configValue = this.form.configValue
            let orderNum = this.form.orderNum
            let status = this.form.status
            let remark = this.form.remark
            this.fullscreenLoading = true
            this.$Api.addConfig({ typeCode, configName, configKey, configValue, orderNum, status, remark }).then((result) => {
              this.fullscreenLoading = false
              this.search()
              this.open = false
              this.$message({
                message: '添加成功',
                type: 'success'
              })
            }).catch(() => {
              this.fullscreenLoading = false
            })
          } else {
            let pkid = this.form.pkid
            let configName = this.form.configName
            let configKey = this.form.configKey
            let configValue = this.form.configValue
            let orderNum = this.form.orderNum
            let status = this.form.status
            let remark = this.form.remark
            this.fullscreenLoading = true
            this.$Api.editConfigDetail({ pkid, configName, configKey, configValue, orderNum, status, remark }).then((r) => {
              this.fullscreenLoading = false
              this.search()
              this.open = false
              this.$message({
                message: ' 修改成功',
                type: 'success'
              })
            }).catch(() => {
              this.fullscreenLoading = false
            })
          }
        }
      })
    },
    cancel () {
      this.open = false
    },
    typeNameFormatter (row, column) {
      let obj = this.typeCodeOptions.find(o => o.typeCode === row.typeCode)
      return obj.typeName
    },
    statusFilterHandler (value, row, column) {

    }
  }
}
</script>

<style lang="scss" scoped>
.width120{
  width: 120px;
}
</style>
