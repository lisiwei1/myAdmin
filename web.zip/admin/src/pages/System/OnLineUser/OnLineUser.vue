<template>
  <div>
    <el-button @click="getList" type="primary" size="mini" icon="el-icon-search">查询</el-button>
    <el-table :data="tableData" v-loading="loading" :height="tableHeight"
      style="width: 100%">
      <el-table-column type="index" label="用户编号" width="100" align="center"></el-table-column>
      <el-table-column prop="loginName" label="用户名" width="100"></el-table-column>
      <el-table-column prop="userName" label="用户昵称" width="100"></el-table-column>
      <el-table-column prop="status" label="状态" :formatter="statusFormatter" width="100"></el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="200"></el-table-column>
      <el-table-column prop="loginIp" label="登录ip" width="150"></el-table-column>
      <el-table-column prop="loginTime" label="登录时间" width="200"></el-table-column>
      <el-table-column prop="remark" label="备注" width="150" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column label="操作" width="180" align="center">
        <template slot-scope="scope">
          <el-button
            icon="el-icon-switch-button"
            @click="handleLogout(scope.row)"
            type="text" size="small">
            下线</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  name: 'OnLineUser',
  data () {
    return {
      loading: false,
      tableData: [],
      tableHeight: 0
    }
  },
  created () {
    this.getList()
  },
  mounted () {
    this.$nextTick(() => {
      this.tableHeight = window.innerHeight - 230
    })
  },
  methods: {
    getList () {
      this.loading = true
      this.$Api.getOnLineUserList().then((result) => {
        this.loading = false
        this.tableData = result
      }).catch(() => { this.loading = false })
    },
    handleLogout (row) {
      let userId = row.pkid
      this.$confirm('是否确认用户: ' + row.loginName + ' ?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$Api.logoutUser({ userId }).then(response => {
          this.$message({
            message: '下线成功',
            type: 'success'
          })
          this.getList()
        })
      }).catch()
    }
  }
}
</script>

<style>
</style>
