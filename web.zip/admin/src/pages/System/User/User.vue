<template>
  <div>
    <el-button @click="handleAdd" type="primary" plain size="mini" icon="el-icon-plus">新增</el-button>
    <el-button @click="getList" type="primary" size="mini" icon="el-icon-search">查询</el-button>
    <el-table :data="tableData" v-loading="loading" :height="tableHeight"
      style="width: 100%">
      <el-table-column type="index" label="用户编号" width="100" align="center"></el-table-column>
      <el-table-column prop="loginName" label="用户名" width="100"></el-table-column>
      <el-table-column prop="userName" label="用户昵称" width="100"></el-table-column>
      <el-table-column prop="status" label="状态" :formatter="statusFormatter" width="100"></el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="200"></el-table-column>
      <el-table-column prop="loginIp" label="登录ip" width="150"></el-table-column>
      <el-table-column prop="loginTime" label="登录时间" width="200"></el-table-column>
      <el-table-column prop="remark" label="备注" width="150" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column label="操作" width="180" align="center">
        <template slot-scope="scope">
          <el-button
            icon="el-icon-edit"
            @click="handleEdit(scope.row)"
            type="text" size="small">
            修改</el-button>
            <el-button v-if="!isAdmin(scope.row.pkid)" size="mini" type="text" icon="el-icon-delete"
              @click="handleDelete(scope.row)">
              删除</el-button>
          <el-button size="mini" type="text" icon="el-icon-key"
            @click="handleResetPwd(scope.row)">
            重置密码</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog :title="title" :visible.sync="open"
      width="600px" :close-on-click-modal="false">
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-form-item label="用户名" prop="loginName">
          <el-input v-model="form.loginName" :disabled="form.isEdit" placeholder="请输入用户名"></el-input>
        </el-form-item>
        <el-form-item label="用户昵称">
          <el-input v-model="form.userName" placeholder="请输入用户昵称"></el-input>
        </el-form-item>
        <el-form-item v-if="form.isShowPassword" label="用户密码" prop="password">
          <el-input v-model="form.password"  placeholder="请输入用户密码"></el-input>
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="form.status">
            <el-radio label="1">正常</el-radio>
            <el-radio label="0">停用</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="角色">
          <el-select v-model="form.roleIds" multiple placeholder="请选择">
            <el-option
              v-for="item in roleOptions"
              :key="item.pkid"
              :label="item.roleName"
              :value="item.pkid"
              :disabled="item.status == 0">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" placeholder="请输入内容"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: 'User',
  components: {
  },
  data () {
    return {
      loading: false,
      tableData: [],
      // 是否显示弹出层
      open: false,
      // 弹出层标题
      title: '',
      // 角色选项
      roleOptions: [],
      form: {
        userId: '',
        loginName: '',
        userName: '',
        password: '',
        status: '',
        remark: '',
        roleIds: [],
        // 是否显示密码框
        isShowPassword: '',
        isEdit: false
      },
      rules: {
        loginName: [
          { required: true, message: '请输入用户名', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入用户密码', trigger: 'blur' }
        ]
      },
      tableHeight: 0
    }
  },
  created () {
    this.getList()
  },
  mounted () {
    this.$nextTick(() => {
      this.tableHeight = window.innerHeight - 230
    })
  },
  methods: {
    getList () {
      this.loading = true
      this.$Api.getSystemUserList().then((result) => {
        this.loading = false
        this.tableData = result
      }).catch(() => { this.loading = false })
    },
    // 新增按钮
    handleAdd () {
      this.reset()
      this.form.isShowPassword = true
      this.$Api.getRoleList().then((result) => {
        this.open = true
        this.title = '添加用户'
        this.form.status = '1'
        this.roleOptions = result
        this.form.isEdit = false
      })
    },
    // 重置表单数据及相关数据
    reset () {
      this.roleOptions = []
      Object.keys(this.form).forEach(key => { this.form[key] = undefined })
    },
    // 取消按钮
    cancel () {
      this.open = false
      this.reset()
    },
    // 修改
    handleEdit (row) {
      let userId = row.pkid
      this.title = '修改用户'
      this.form.isShowPassword = false
      this.reset()
      this.$Api.getUserDetail({ userId }).then((result) => {
        let user = result.user
        this.form.userId = user.pkid
        this.form.loginName = user.loginName
        this.form.userName = user.userName
        this.form.status = user.status.toString()
        this.form.remark = user.remark
        this.form.roleIds = result.roleIds
        this.form.isEdit = true
        this.$Api.getRoleList().then((result) => {
          this.roleOptions = result
          this.open = true
        })
      })
    },
    // 提交表单
    submitForm () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          if (this.form.userId != undefined) {
            let userId = this.form.userId
            let status = this.form.status
            let remark = this.form.remark
            let userName = this.form.userName
            let roleIds = this.form.roleIds.toString()
            this.$Api.editUser({ userId, userName, status, remark, roleIds }).then(
              this.$message({
                message: '修改成功',
                type: 'success'
              })
            )
            this.open = false
            this.getList()
          } else {
            this.$Api.addUser(this.form).then(response => {
              this.$message({
                message: '新增成功',
                type: 'success'
              })
              this.open = false
              this.getList()
            })
          }
        }
      })
    },
    // 校验是否为超级用户
    isAdmin (pkid) {
      if (pkid == 1) {
        return true
      }
      return false
    },
    // 删除用户
    handleDelete (row) {
      let userId = row.pkid
      this.$confirm('是否确认删除用户: ' + row.loginName + ' ?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$Api.deleteUser({ userId }).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    statusFormatter (row, column) {
      if (row.status == 1) {
        return '正常'
      } else if (row.status == 0) {
        return '停用'
      }
      return row.status
    },
    /** 重置密码按钮操作 */
    handleResetPwd (row) {
      this.$prompt('请输入"' + row.loginName + '"的新密码', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value == null || value == '') {
          this.$message({
            message: '密码不能为空',
            type: 'warning'
          })
          return
        }
        let pkid = row.pkid
        let password = value
        this.$Api.resetPwd({ pkid, password }).then(response => {
          this.$message({
            message: '修改成功，新密码是：' + password,
            type: 'success'
          })
        })
      }).catch(() => {})
    }
  }
}
</script>
