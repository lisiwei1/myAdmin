<template>
  <div>
    <el-button @click="handleAdd()" type="primary" plain size="mini" icon="el-icon-plus">新增</el-button>
    <el-button @click="search()" type="primary" size="mini" icon="el-icon-search">查询</el-button>
    <el-table :data="tableData" row-key="pkid" style="width: 100%" :height="tableHeight" v-loading="loading"
          :default-sort = "{prop: 'orderNum'}">
      <el-table-column prop="menuName" label="菜单名称" width="300"></el-table-column>
      <el-table-column prop="path" label="路由地址" width="150"></el-table-column>
      <el-table-column prop="status" label="状态" :formatter="statusFormat" width="100"></el-table-column>
      <el-table-column prop="orderNum" label="排序" width="100"></el-table-column>
      <el-table-column prop="component" label="组件路径" width="200"></el-table-column>
      <el-table-column prop="menuType" label="类型" :formatter="menuTypeFormat" width="100"></el-table-column>
      <el-table-column prop="visible" label="显示状态" :formatter="visibleFormat" width="100"></el-table-column>
      <el-table-column prop="perms" label="权限标识" width="250"></el-table-column>
      <el-table-column fixed="right" label="操作" width="180">
        <template slot-scope="scope">
          <el-button type="text"
            @click="handleEdit(scope.row)"
            size="small"
            icon="el-icon-edit"
            >修改</el-button>
            <el-button
              size="mini"
              type="text"
              icon="el-icon-plus"
              @click="handleAdd(scope.row)"
            >新增</el-button>
          <el-button
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            size="small"
            >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog :title="title" :visible.sync="open" width="800px" :close-on-click-modal="false">
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-row>
          <el-col :span="24">
            <el-form-item label="上级菜单" prop="menuId">
              <el-cascader
                  @change="handleChange"
                  style="width: 450px;"
                  clearable
                  v-model="form.menuId"
                  :options="menuOptions"
                  :props="props"></el-cascader>
            </el-form-item>
            <el-form-item label="菜单类型">
             <el-radio-group v-model="form.menuType">
                <el-radio label="1">目录</el-radio>
                <el-radio label="2">菜单</el-radio>
                <el-radio label="3">按钮</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="菜单名称" prop="menuName">
              <el-input v-model="form.menuName"  placeholder="请输入菜单名称"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="显示顺序">
              <el-input-number v-model="form.orderNum" controls-position="right" :min="0" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item v-if="form.menuType != '3'" label="路由地址" prop="path">
              <el-input v-model="form.path"  placeholder="请输入路由地址"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item v-if="form.menuType == '2'" label="组件路径">
              <el-input v-model="form.component"  placeholder="请输入组件路径"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item v-if="form.menuType != '1'" label="权限标识">
              <el-input v-model="form.perms" placeholder="请输入权限标识" maxlength="50" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item v-if="form.menuType != '3'" label="显示状态">
              <el-radio-group v-model="form.visible">
                 <el-radio label="1">显示</el-radio>
                 <el-radio label="0">隐藏</el-radio>
               </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item v-if="form.menuType != '3'" label="菜单状态">
              <el-radio-group v-model="form.status">
                 <el-radio label="1">正常</el-radio>
                 <el-radio label="0">停用</el-radio>
               </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
export default {
  name: 'Menu',
  data () {
    return {
      loading: false,
      tableData: [],
      tableHeight: 0,
      title: '',
      open: false,
      menuOptions: [],
      isEdit: false,
      form: {
        pkid: '',
        menuId: '',
        parentId: '',
        menuType: '1',
        menuName: '',
        component: '',
        perms: '',
        orderNum: 0,
        visible: '1',
        status: '1'
      },
      rules: {
        menuId: [
          { required: true, message: '上级菜单不能为空', trigger: 'blur' }
        ],
        menuName: [
          { required: true, message: '菜单名称不能为空', trigger: 'blur' }
        ],
        path: [
          { required: true, message: '路由地址不能为空', trigger: 'blur' }
        ]
      },
      props: {
        label: 'menuName',
        value: 'pkid',
        checkStrictly: 'true'
      },
      mainArr: { pkid: 0, menuName: '主目录' }
    }
  },
  created () {
    this.search()
  },
  mounted () {
    this.$nextTick(() => {
      this.tableHeight = window.innerHeight - 200
    })
  },
  methods: {
    search () {
      this.loading = true
      this.$Api.getMenuList().then((result) => {
        this.loading = false
        this.tableData = result
      }).catch(() => {
        this.loading = false
      })
    },
    reSet () {
      Object.keys(this.form).forEach(key => { this.form[key] = undefined })
      this.form.orderNum = 0
      this.form.menuType = '1'
      this.form.visible = '1'
      this.form.status = '1'
    },
    handleAdd (row) {
      console.log(row)
      // 以后可以优化，找出选择节点的所有父节点
      this.reSet()
      this.$Api.getMenuList().then((result) => {
        if (row) {
          this.form.menuId = row.parentId
        }
        this.menuOptions = result
        this.menuOptions.unshift(this.mainArr)
        this.title = '添加菜单'
        this.open = true
        this.isEdit = false
      })
    },
    handleEdit (row) {
      this.reSet()
      this.$Api.getMenuList().then((result) => {
        // 父节点的pkid也要push进来

        this.menuOptions = result
        this.menuOptions.unshift(this.mainArr)
        let d = { pkid: row.pkid }
        this.$Api.getMenu(d).then(response => {
          this.title = '修改菜单'
          this.open = true
          this.isEdit = true
          this.form = { ...response }
          this.form.menuId = response.parentId
          this.form.menuType = response.menuType.toString()
          this.form.visible = response.visible.toString()
          this.form.status = response.status.toString()
        })
      })
    },
    handleDelete (row) {
      let pkid = row.pkid
      this.$confirm('是否确认删除权限: ' + row.menuName + ' ?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$Api.deleteMenu({ pkid }).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.search()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    submitForm () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          // 过滤数据
          // 菜单类型（1目录 2菜单 3按钮）
          let req = { ...this.form }
          if (req.menuType == 1) {
            req.component = ''
            req.perms = ''
            req.icon = 'folder-o'
          } else if (req.menuType == 3) {
            req.component = ''
            req.path = ''
            req.visible = 1
            req.status = 1
          }

          // 找父节点
          if (Array.isArray(req.menuId)) {
            req.parentId = req.menuId[req.menuId.length - 1]
          } else {
            req.parentId = req.menuId
          }
          if (this.isEdit) {
            console.log('req', req)
            this.$Api.editMenu(req).then(response => {
              this.$message({
                message: '修改成功',
                type: 'success'
              })
              this.open = false
              this.search()
            })
          } else {
            this.$Api.addMenu(req).then(response => {
              this.$message({
                message: '添加成功',
                type: 'success'
              })
              this.open = false
              this.search()
            })
          }
        }
      })
    },
    handleChange (value) {
      console.log('===', this.menuOptions)
      console.log(value)
    },
    // 根据类型过滤数据

    menuTypeFormat (row, column) {
      // 菜单类型（1目录 2菜单 3按钮）
      if (row.menuType == 1) {
        return '目录'
      }
      if (row.menuType == 2) {
        return '菜单'
      }
      if (row.menuType == 3) {
        return '按钮'
      }
    },
    statusFormat (row, column) {
      // 菜单类型（1目录 2菜单 3按钮）
      if (row.menuType == 3) {
        return ''
      }
      // 菜单状态（0停用 1正常）
      if (row.status === 1) {
        return '正常'
      }
      return '停用'
    },
    visibleFormat (row, column) {
      // 菜单类型（1目录 2菜单 3按钮）
      if (row.menuType == 3) {
        return ''
      }
      // 菜单状态（0隐藏 1显示）
      if (row.visible == 0) {
        return '隐藏'
      } if (row.visible == 1) {
        return '显示'
      }
      return ''
    },
    cancel () {
      this.open = false
    }

  }
}
</script>

<style>
</style>
