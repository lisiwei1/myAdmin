import request from '@/plugin/axios'

export default {
  getRoleList: (data) => request({
    url: '/role/getRoleList',
    method: 'get',
    data
  }),
  addRole: (data) => request({
    url: '/role/addRole',
    method: 'post',
    data
  }),
  deleteRole: (data) => request({
    url: '/role/deleteRole',
    method: 'postget',
    data
  }),
  getRoleDetail: (data) => request({
    url: '/role/getRoleDetail',
    method: 'get',
    data
  }),
  editRole: (data) => request({
    url: '/role/editRole',
    method: 'post',
    data
  }),
  editRoleConfigType: (data) => request({
    url: '/role/editRoleConfigType',
    method: 'post',
    data
  }),
  getRoleConfigTypeDetail: (data) => request({
    url: '/role/getRoleConfigTypeDetail',
    method: 'postget',
    data
  }),
}
