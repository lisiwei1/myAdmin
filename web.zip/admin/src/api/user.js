import request from '@/plugin/axios'

export default {
  getSystemUserList: (data) => request({
    url: '/user/getUserList',
    method: 'get',
    data
  }),
  getUserDetail: (data) => request({
    url: '/user/getUserDetail',
    method: 'get',
    data
  }),
  resetPwd: (data) => request({
    url: '/user/resetPwd',
    method: 'postget',
    data
  }),
  changePassword: (data) => request({
    url: '/user/changePassword',
    method: 'postget',
    data
  }),
  addUser: (data) => request({
    url: '/user/addUser',
    method: 'post',
    data
  }),
  deleteUser: (data) => request({
    url: '/user/deleteUser',
    method: 'postget',
    data
  }),
  editUser: (data) => request({
    url: '/user/editUser',
    method: 'postget',
    data
  }),
  requestTest: (data) => request({
    url: '/user/requestTest',
    method: 'get',
    data
  }),
  getSystemUserList: (data) => request({
    url: '/login/defaultKaptcha',
    method: 'get',
    data
  }),
}
