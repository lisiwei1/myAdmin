import request from '@/plugin/axios'

export default {
  getConfigTypeList: (data) => request({
    url: '/config/getTypeList',
    method: 'get',
    data
  }),
  getConfigTypeListByUser: (data) => request({
    url: '/config/getTypeListByUser',
    method: 'get',
    data
  }),
  addConfigType: (data) => request({
    url: '/config/addType',
    method: 'postget',
    data
  }),
  getTypeDetail: (data) => request({
    url: '/config/getTypeDetail',
    method: 'postget',
    data
  }),
  editConfigType: (data) => request({
    url: '/config/editType',
    method: 'postget',
    data
  }),
  deleteConfigType: (data) => request({
    url: '/config/deleteType',
    method: 'postget',
    data
  }),
  getConfigDetailList: (data) => request({
    url: '/config/getConfigList',
    method: 'postget',
    data
  }),
  addConfig: (data) => request({
    url: '/config/addConfig',
    method: 'postget',
    data
  }),
  deleteConfig: (data) => request({
    url: '/config/deleteConfig',
    method: 'postget',
    data
  }),
  getConfigDetail: (data) => request({
    url: '/config/getConfigDetail',
    method: 'postget',
    data
  }),
  editConfigDetail: (data) => request({
    url: '/config/editConfig',
    method: 'postget',
    data
  }),
  editConfigDeatilStatus: (data) => request({
    url: '/config/editConfigDeatilStatus',
    method: 'postget',
    data
  }),
  getConfigValueFromCache: (data) => request({
    url: '/config/getConfigValueFromCache',
    method: 'postget',
    data
  }),
  getMsgConfigList: (data) => request({
    url: '/config/getMsgConfigList',
    method: 'postget',
    data
  }),
  editMsgConfigEnable: (data) => request({
    url: '/config/editMsgConfigEnable',
    method: 'postget',
    data
  }),
}
