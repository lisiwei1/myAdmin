const files = require.context('.', true, /\.js$/);

let Api = {};
/**
 * inject routers
 */
files.keys().forEach((key) => {
  if (key === './index.js') return;
  Api = Object.assign(Api, files(key).default); // 读取出文件中的default模块

});
export default Api;
