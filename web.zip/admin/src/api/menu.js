import request from '@/plugin/axios'

export default {
  getMenuList: (data) => request({
    url: '/menu/menuList',
    method: 'get',
    data
  }),
  addMenu: (data) => request({
    url: '/menu/addMenu',
    method: 'post',
    data
  }),
  deleteMenu: (data) => request({
    url: '/menu/deleteMenu',
    method: 'postget',
    data
  }),
  getMenu: (data) => request({
    url: '/menu/getMenu',
    method: 'get',
    data
  }),
  editMenu: (data) => request({
    url: '/menu/editMenu',
    method: 'post',
    data
  }),
}
