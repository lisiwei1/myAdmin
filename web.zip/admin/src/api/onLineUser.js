import request from '@/plugin/axios'

export default {
  getOnLineUserList: (data) => request({
    url: '/login/getOnLineUserList',
    method: 'get',
    data
  }),
  logoutUser: (data) => request({
    url: '/login/logoutUser',
    method: 'postget',
    data
  }),
  logoutMySelf: (data) => request({
    url: '/login/logoutMySelf',
    method: 'postget',
    data
  }),
}