const all = require('./src/index.js')
module.exports = all
